import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";

import Newsletter from "./newsletter/Newsletter.js";
import BlankPage from "./blankpage/BlankPage.js";

const App = () => {
  return (
    <div>
      <BrowserRouter>
        <Switch>
          <Route path="/blank" exact component={BlankPage} />
          <Newsletter />
        </Switch>
      </BrowserRouter>
    </div>
  );
};

export default App;
