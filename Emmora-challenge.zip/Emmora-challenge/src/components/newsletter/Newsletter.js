import React, { useState } from "react";
import Modal from "./Modal.js";

const Newsletter = () => {
	const [showPopup, setState] = useState(false);

	const toggle = () => {
		setState(!showPopup);
	};

	return (
		<div>
			<div className="newsletter">
				<div className="newsletter-header">
					<p>
						<b>Here</b> sign up for our Newsletter.
					</p>
					<div>
						<input
							type="email"
							name="email"
							placeholder="Your Email address"
						/>
						<input type="submit" value="Join" onClick={toggle} />

						{showPopup ? <Modal closePopup={toggle} /> : null}
					</div>
				</div>
			</div>
		</div>
	);
};
export default Newsletter;
