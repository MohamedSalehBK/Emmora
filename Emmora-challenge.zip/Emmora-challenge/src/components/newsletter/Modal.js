import React from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";

import Logo from "../../styles/images/icons/logo.png";

const Modal = props => {
  return (
    <div>
      <div className="modal">
        <div className="modal_inner">
          <Link to="/blank">
            <div className="close" onClick={props.closePopup}></div>
          </Link>
          <h3>Vielen Dank Für Ihre Anmeldung</h3>
          <h3>Zum Unserm Newsletter.</h3>

          <p>Herzliche Grüße,</p>
          <p>Ihr Emmora-Team</p>

          <button>Zurük Zur Seite </button>

          <div>
            <img className="logo" src={Logo} alt="Logo" />
          </div>
        </div>
      </div>
    </div>
  );
};

Modal.propTypes = {
  closePopup: PropTypes.func
};

export default Modal;
