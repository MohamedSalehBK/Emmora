import React from "react";

const BlankPage = () => {
	return (
		<div className="newsletter-header">
			Hallo, There is nothig here just BlankPage!
		</div>
	);
};

export default BlankPage;
